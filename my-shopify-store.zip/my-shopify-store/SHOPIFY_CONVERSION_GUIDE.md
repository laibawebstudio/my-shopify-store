# Shopify Online Store 2.0 Conversion Guide
## Porting LUMINA Atelier from HTML/CSS/JS to a Production Shopify OS 2.0 Theme

This storefront was intentionally architected from the ground up to mirror the modular component hierarchy of **Shopify Online Store 2.0** (like Shopify Dawn, Prestige, and Sense themes).

---

## 1. Directory Structure Mapping

When creating your Shopify 2.0 theme (e.g. via `shopify theme init`), organize files according to this mapping:

| Static HTML/CSS/JS File | Shopify Theme Equivalent | Purpose |
| :--- | :--- | :--- |
| `index.html` (announcement bar) | `sections/announcement-bar.liquid` | Customizable header ticker |
| `index.html` (header & nav) | `sections/header.liquid` | Dynamic logo, navigation menu, and action icons |
| `index.html` (hero banner) | `sections/hero-banner.liquid` | Full-width editorial hero with schema controls |
| `index.html` (perks bar) | `sections/perks-banner.liquid` | Value proposition badges |
| `index.html` (category tiles) | `sections/collection-list.liquid` | Collection teaser blocks |
| `index.html` (product grid) | `sections/featured-collection.liquid` | Dynamic product loop with collection picker |
| `index.html` (storytelling split) | `sections/image-with-text.liquid` | Brand heritage section |
| `index.html` (patron reviews) | `sections/testimonials.liquid` | Customer reviews block with star ratings |
| `index.html` (newsletter) | `sections/newsletter.liquid` | Native Shopify customer subscription form |
| `index.html` (footer) | `sections/footer.liquid` | Multi-column links & payment provider icons |
| `assets/css/variables.css` | `assets/base.css` + `config/settings_schema.json` | Global theme design tokens & colors |
| `assets/css/components.css` | `assets/components.css` | Section-specific styles |
| `assets/css/cart.css` | `assets/cart-drawer.css` | Slide-over drawer and modal styling |
| `assets/js/cart.js` | `assets/cart-drawer.js` | Shopify AJAX Cart API integration |
| Product card markup | `snippets/card-product.liquid` | Reusable product card component |
| Quick view modal | `snippets/quick-view-modal.liquid` | Modal product variant selector |
| Search modal | `snippets/predictive-search.liquid` | Predictive search overlay |

---

## 2. Converting Cart JavaScript to Shopify AJAX Cart API

In `assets/js/cart.js`, replace the mock `localStorage` methods with Shopify's native AJAX Cart endpoints:

### Add to Cart (`/cart/add.js`):
```javascript
async function addShopifyItem(variantId, quantity = 1) {
  const response = await fetch(window.routes.cart_add_url || '/cart/add.js', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      id: variantId,
      quantity: quantity
    })
  });
  const item = await response.json();
  refreshShopifyCart();
}
```

### Fetch Cart & Update Drawer (`/cart.js`):
```javascript
async function refreshShopifyCart() {
  const response = await fetch(window.routes.cart_url || '/cart.js');
  const cart = await response.json();
  
  // Update item count badge
  document.querySelectorAll('.cart-count-badge').forEach(badge => {
    badge.textContent = cart.item_count;
  });

  // Calculate free shipping bar ($150 target = 15000 cents in Shopify)
  const freeShippingThresholdCents = 15000;
  const remaining = Math.max(0, freeShippingThresholdCents - cart.total_price);
  const fillPct = Math.min(100, (cart.total_price / freeShippingThresholdCents) * 100);
  
  document.getElementById('shippingProgressFill').style.width = `${fillPct}%`;
}
```

### Change Quantity / Remove (`/cart/change.js`):
```javascript
async function updateShopifyItem(lineIndex, quantity) {
  await fetch(window.routes.cart_change_url || '/cart/change.js', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      line: lineIndex,
      quantity: quantity
    })
  });
  refreshShopifyCart();
}
```

---

## 3. Creating `templates/index.json` (Shopify OS 2.0 Template)

Shopify OS 2.0 uses JSON templates to define section order and block settings. In your Shopify theme, create `templates/index.json`:

```json
{
  "sections": {
    "hero_banner": {
      "type": "hero-banner",
      "settings": {
        "badge_text": "Autumn / Winter 2026 Collection",
        "heading": "<p>Timeless Essentials, <em>Modern Sophistication</em>.</p>",
        "button_1_label": "Explore Collection",
        "button_1_link": "#featuredCollectionSection"
      }
    },
    "perks_bar": {
      "type": "perks-banner",
      "settings": {}
    },
    "collection_list": {
      "type": "collection-list",
      "settings": {
        "title": "Designed for Living Well"
      }
    },
    "featured_collection": {
      "type": "featured-collection",
      "settings": {
        "title": "Iconic Atelier Releases",
        "products_to_show": 8,
        "show_secondary_image": true,
        "show_rating": true
      }
    },
    "story_split": {
      "type": "image-with-text",
      "settings": {
        "title": "Crafted with Intention. Designed to Outlast."
      }
    },
    "testimonials": {
      "type": "testimonials",
      "settings": {
        "title": "Endorsed by Connoisseurs"
      }
    },
    "newsletter": {
      "type": "newsletter",
      "settings": {
        "heading": "Join The Atelier Circle"
      }
    }
  },
  "order": [
    "hero_banner",
    "perks_bar",
    "collection_list",
    "featured_collection",
    "story_split",
    "testimonials",
    "newsletter"
  ]
}
```

---

## 4. Theme Settings & Design Tokens (`config/settings_schema.json`)

Map the CSS variables from `assets/css/variables.css` into Shopify theme customizer settings:

```json
[
  {
    "name": "Colors",
    "settings": [
      {
        "type": "color",
        "id": "color_primary",
        "label": "Primary Accent",
        "default": "#171717"
      },
      {
        "type": "color",
        "id": "color_secondary",
        "label": "Secondary Gold/Bronze",
        "default": "#C59B6C"
      },
      {
        "type": "color",
        "id": "color_bg_main",
        "label": "Page Background",
        "default": "#FAF9F6"
      }
    ]
  },
  {
    "name": "Cart",
    "settings": [
      {
        "type": "checkbox",
        "id": "show_free_shipping_bar",
        "label": "Enable Free Shipping Goal Bar",
        "default": true
      },
      {
        "type": "number",
        "id": "free_shipping_goal",
        "label": "Free Shipping Threshold ($)",
        "default": 150
      }
    ]
  }
]
```

In `layout/theme.liquid`, render these variables inside `<style>`:
```liquid
:root {
  --color-primary: {{ settings.color_primary }};
  --color-secondary: {{ settings.color_secondary }};
  --color-bg-main: {{ settings.color_bg_main }};
}
```

---

## 5. Development & Preview with Shopify CLI

Once migrated into the theme folder:

```bash
# 1. Log into your Shopify Partner store
shopify login --store your-store-handle.myshopify.com

# 2. Start hot-reloading development server
shopify theme dev

# 3. Push to production or publish live
shopify theme push --live
```
