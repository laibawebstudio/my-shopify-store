/* ==========================================================================
   LUMINA ATELIER - WISHLIST LOGIC (wishlist.js)
   Persists user favorites & updates header counter
   ========================================================================== */

class WishlistManager {
  constructor() {
    this.key = 'lumina_wishlist_ids';
    this.items = this.loadWishlist();
    this.badges = document.querySelectorAll('.wishlist-count-badge');
    
    this.initEvents();
    this.render();
  }

  loadWishlist() {
    try {
      const stored = localStorage.getItem(this.key);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Error loading wishlist:', e);
    }
    return ["prod-2"]; // 1 initial favorite for visual polish
  }

  saveWishlist() {
    localStorage.setItem(this.key, JSON.stringify(this.items));
  }

  initEvents() {
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-wishlist-id]');
      if (btn) {
        e.preventDefault();
        const id = btn.getAttribute('data-wishlist-id');
        this.toggle(id, btn);
      }
    });
  }

  toggle(productId, buttonEl) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    const index = this.items.indexOf(productId);

    if (index > -1) {
      this.items.splice(index, 1);
      if (buttonEl) buttonEl.classList.remove('active');
      if (window.cartManager) {
        window.cartManager.showToast(`Removed from your wishlist.`);
      }
    } else {
      this.items.push(productId);
      if (buttonEl) buttonEl.classList.add('active');
      if (window.cartManager) {
        window.cartManager.showToast(`Saved ${product ? product.title : 'item'} to your wishlist.`);
      }
    }

    this.saveWishlist();
    this.render();
  }

  isWishlisted(productId) {
    return this.items.includes(productId);
  }

  render() {
    this.badges.forEach(badge => {
      badge.textContent = this.items.length;
    });

    // Update heart icons on page
    document.querySelectorAll('[data-wishlist-id]').forEach(btn => {
      const id = btn.getAttribute('data-wishlist-id');
      if (this.isWishlisted(id)) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.wishlistManager = new WishlistManager();
});
