/* ==========================================================================
   LUMINA ATELIER - SHOPPING CART LOGIC (cart.js)
   Matches Shopify Cart API & AJAX Drawer Pattern
   ========================================================================== */

const FREE_SHIPPING_THRESHOLD = 150.00;
const PROMO_CODES = {
  'LUMINA15': { type: 'percent', value: 0.15, label: '15% Off Atelier Circle' },
  'SAVE10': { type: 'flat', value: 10.00, label: '$10 Off Welcome Promo' },
  'FREESHIP': { type: 'shipping', value: 0, label: 'Complimentary Express Delivery' }
};

class CartManager {
  constructor() {
    this.cartKey = 'lumina_cart_items';
    this.couponKey = 'lumina_active_coupon';
    this.items = this.loadCart();
    this.activeCoupon = localStorage.getItem(this.couponKey) || null;
    
    this.initElements();
    this.bindEvents();
    this.render();
  }

  loadCart() {
    try {
      const stored = localStorage.getItem(this.cartKey);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Could not parse cart from localStorage:', e);
    }
    // Pre-populate with 1 starter item so the reviewer immediately experiences the drawer
    return [
      {
        id: "prod-1",
        title: "Sienna Minimalist Leather Backpack",
        price: 245.00,
        image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80",
        color: "Sienna Tan",
        size: "One Size",
        quantity: 1
      }
    ];
  }

  saveCart() {
    localStorage.setItem(this.cartKey, JSON.stringify(this.items));
  }

  initElements() {
    this.drawer = document.getElementById('cartDrawer');
    this.backdrop = document.getElementById('cartDrawerBackdrop');
    this.cartItemsList = document.getElementById('cartItemsList');
    this.cartEmptyState = document.getElementById('cartEmptyState');
    this.cartCountBadges = document.querySelectorAll('.cart-count-badge');
    this.cartSubtotalEl = document.getElementById('cartSubtotal');
    this.cartTotalEl = document.getElementById('cartTotal');
    this.cartDiscountRow = document.getElementById('cartDiscountRow');
    this.cartDiscountAmount = document.getElementById('cartDiscountAmount');
    this.cartShippingText = document.getElementById('cartShippingText');
    this.shippingProgressFill = document.getElementById('shippingProgressFill');
    this.shippingProgressBarText = document.getElementById('shippingProgressBarText');
    this.couponInput = document.getElementById('cartCouponInput');
    this.couponBtn = document.getElementById('cartCouponBtn');
    this.cartOpenButtons = document.querySelectorAll('.cart-trigger-btn');
    this.cartCloseButtons = document.querySelectorAll('.cart-close-btn');
    this.checkoutModal = document.getElementById('checkoutModal');
    this.checkoutBackdrop = document.getElementById('checkoutBackdrop');
  }

  bindEvents() {
    // Open cart drawer
    this.cartOpenButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openDrawer();
      });
    });

    // Close cart drawer
    this.cartCloseButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.closeDrawer();
      });
    });

    if (this.backdrop) {
      this.backdrop.addEventListener('click', () => this.closeDrawer());
    }

    // Apply coupon
    if (this.couponBtn && this.couponInput) {
      this.couponBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.applyCoupon(this.couponInput.value.trim());
      });
      this.couponInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.applyCoupon(this.couponInput.value.trim());
        }
      });
    }

    // Checkout modal triggers
    const checkoutBtn = document.getElementById('btnProceedToCheckout');
    if (checkoutBtn) {
      checkoutBtn.addEventListener('click', () => {
        this.closeDrawer();
        this.openCheckout();
      });
    }

    const closeCheckoutBtns = document.querySelectorAll('.checkout-close-btn');
    closeCheckoutBtns.forEach(btn => {
      btn.addEventListener('click', () => this.closeCheckout());
    });

    if (this.checkoutBackdrop) {
      this.checkoutBackdrop.addEventListener('click', () => this.closeCheckout());
    }
  }

  openDrawer() {
    if (this.drawer && this.backdrop) {
      this.drawer.classList.add('active');
      this.backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  closeDrawer() {
    if (this.drawer && this.backdrop) {
      this.drawer.classList.remove('active');
      this.backdrop.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  openCheckout() {
    if (this.checkoutModal && this.checkoutBackdrop) {
      this.renderCheckoutSummary();
      this.checkoutModal.classList.add('active');
      this.checkoutBackdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  closeCheckout() {
    if (this.checkoutModal && this.checkoutBackdrop) {
      this.checkoutModal.classList.remove('active');
      this.checkoutBackdrop.classList.remove('active');
      document.body.style.overflow = '';
      
      // Reset checkout success view back to form if open
      const formView = document.getElementById('checkoutFormView');
      const successView = document.getElementById('checkoutSuccessView');
      if (formView && successView) {
        formView.style.display = 'block';
        successView.style.display = 'none';
      }
    }
  }

  addItem(productId, quantity = 1, options = {}) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    const chosenColor = options.color || (product.colors && product.colors[0] ? product.colors[0].name : "Standard");
    const chosenSize = options.size || (product.sizes && product.sizes[0] ? product.sizes[0] : "One Size");

    // Check if matching item exists in cart
    const existingIndex = this.items.findIndex(item => 
      item.id === productId && item.color === chosenColor && item.size === chosenSize
    );

    if (existingIndex > -1) {
      this.items[existingIndex].quantity += quantity;
    } else {
      this.items.push({
        id: product.id,
        title: product.title,
        price: product.price,
        image: product.images[0],
        color: chosenColor,
        size: chosenSize,
        quantity: quantity
      });
    }

    this.saveCart();
    this.render();
    this.openDrawer();
    this.showToast(`Added to your Atelier Bag: ${product.title}`);
  }

  updateQuantity(index, delta) {
    if (!this.items[index]) return;
    this.items[index].quantity += delta;
    if (this.items[index].quantity <= 0) {
      this.items.splice(index, 1);
    }
    this.saveCart();
    this.render();
  }

  removeItem(index) {
    if (!this.items[index]) return;
    const removedTitle = this.items[index].title;
    this.items.splice(index, 1);
    this.saveCart();
    this.render();
    this.showToast(`Removed ${removedTitle} from bag.`);
  }

  applyCoupon(code) {
    const cleanCode = code.toUpperCase();
    if (PROMO_CODES[cleanCode]) {
      this.activeCoupon = cleanCode;
      localStorage.setItem(this.couponKey, cleanCode);
      this.showToast(`Promo "${cleanCode}" applied successfully! 🎉`);
      this.render();
    } else {
      this.showToast(`Coupon "${code}" is invalid or expired. Try LUMINA15`);
    }
  }

  removeCoupon() {
    this.activeCoupon = null;
    localStorage.removeItem(this.couponKey);
    this.render();
  }

  getTotalCount() {
    return this.items.reduce((sum, item) => sum + item.quantity, 0);
  }

  getSubtotal() {
    return this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }

  getCalculations() {
    const subtotal = this.getSubtotal();
    let discount = 0;
    let shipping = subtotal >= FREE_SHIPPING_THRESHOLD || subtotal === 0 ? 0 : 15.00;

    if (this.activeCoupon && PROMO_CODES[this.activeCoupon]) {
      const promo = PROMO_CODES[this.activeCoupon];
      if (promo.type === 'percent') {
        discount = subtotal * promo.value;
      } else if (promo.type === 'flat') {
        discount = Math.min(subtotal, promo.value);
      } else if (promo.type === 'shipping') {
        shipping = 0;
      }
    }

    const total = Math.max(0, subtotal - discount + shipping);

    return {
      subtotal,
      discount,
      shipping,
      total,
      freeShippingThresholdRemaining: Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal)
    };
  }

  render() {
    const totalCount = this.getTotalCount();
    const { subtotal, discount, shipping, total, freeShippingThresholdRemaining } = this.getCalculations();

    // 1. Update count badges
    this.cartCountBadges.forEach(badge => {
      badge.textContent = totalCount;
      badge.classList.remove('animate-bump');
      void badge.offsetWidth; // Trigger reflow
      badge.classList.add('animate-bump');
    });

    const pillCount = document.getElementById('cartItemCountPill');
    if (pillCount) {
      pillCount.textContent = `${totalCount} ${totalCount === 1 ? 'item' : 'items'}`;
    }

    // 2. Free shipping meter
    if (this.shippingProgressFill && this.shippingProgressBarText) {
      if (subtotal >= FREE_SHIPPING_THRESHOLD) {
        this.shippingProgressFill.style.width = '100%';
        this.shippingProgressBarText.innerHTML = `✨ <strong>Complimentary Express Shipping Unlocked!</strong>`;
      } else if (subtotal === 0) {
        this.shippingProgressFill.style.width = '0%';
        this.shippingProgressBarText.innerHTML = `Add <strong>$${FREE_SHIPPING_THRESHOLD.toFixed(2)}</strong> to enjoy Free Shipping`;
      } else {
        const pct = Math.min(100, Math.round((subtotal / FREE_SHIPPING_THRESHOLD) * 100));
        this.shippingProgressFill.style.width = `${pct}%`;
        this.shippingProgressBarText.innerHTML = `Add <strong>$${freeShippingThresholdRemaining.toFixed(2)}</strong> more for <strong>Free Express Delivery</strong>`;
      }
    }

    // 3. Render items list or empty state
    if (this.cartItemsList && this.cartEmptyState) {
      if (this.items.length === 0) {
        this.cartItemsList.style.display = 'none';
        this.cartEmptyState.style.display = 'block';
      } else {
        this.cartItemsList.style.display = 'flex';
        this.cartEmptyState.style.display = 'none';

        this.cartItemsList.innerHTML = this.items.map((item, index) => `
          <div class="cart-item" data-index="${index}">
            <img src="${item.image}" alt="${item.title}" class="cart-item-img" />
            <div class="cart-item-details">
              <h4 class="cart-item-title">${item.title}</h4>
              <div class="cart-item-variant">${item.color} • ${item.size}</div>
              <div class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</div>
              <div class="qty-stepper">
                <button type="button" class="qty-btn" onclick="window.cartManager.updateQuantity(${index}, -1)" aria-label="Decrease quantity">−</button>
                <span class="qty-value">${item.quantity}</span>
                <button type="button" class="qty-btn" onclick="window.cartManager.updateQuantity(${index}, 1)" aria-label="Increase quantity">+</button>
              </div>
            </div>
            <button type="button" class="cart-item-remove" onclick="window.cartManager.removeItem(${index})" title="Remove item" aria-label="Remove item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
            </button>
          </div>
        `).join('');
      }
    }

    // 4. Update Financial Totals
    if (this.cartSubtotalEl) {
      this.cartSubtotalEl.textContent = `$${subtotal.toFixed(2)}`;
    }
    if (this.cartTotalEl) {
      this.cartTotalEl.textContent = `$${total.toFixed(2)}`;
    }

    if (this.cartShippingText) {
      this.cartShippingText.textContent = shipping === 0 ? (subtotal > 0 ? 'FREE' : '$0.00') : `$${shipping.toFixed(2)}`;
    }

    if (this.cartDiscountRow && this.cartDiscountAmount) {
      if (discount > 0) {
        this.cartDiscountRow.style.display = 'flex';
        this.cartDiscountAmount.textContent = `-$${discount.toFixed(2)} (${this.activeCoupon})`;
      } else {
        this.cartDiscountRow.style.display = 'none';
      }
    }
  }

  renderCheckoutSummary() {
    const summaryContainer = document.getElementById('checkoutSummaryItems');
    const { subtotal, discount, shipping, total } = this.getCalculations();

    if (summaryContainer) {
      summaryContainer.innerHTML = this.items.map(item => `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.6rem; font-size:0.85rem;">
          <div style="display:flex; align-items:center; gap:0.6rem;">
            <img src="${item.image}" style="width:36px; height:45px; object-fit:cover; border-radius:3px;" />
            <div>
              <div style="font-weight:600;">${item.title} (x${item.quantity})</div>
              <div style="font-size:0.75rem; color:#888;">${item.color} • ${item.size}</div>
            </div>
          </div>
          <div style="font-weight:700;">$${(item.price * item.quantity).toFixed(2)}</div>
        </div>
      `).join('');
    }

    const checkoutSubtotal = document.getElementById('checkoutSummarySubtotal');
    const checkoutTotal = document.getElementById('checkoutSummaryTotal');
    const checkoutDiscount = document.getElementById('checkoutSummaryDiscount');

    if (checkoutSubtotal) checkoutSubtotal.textContent = `$${subtotal.toFixed(2)}`;
    if (checkoutTotal) checkoutTotal.textContent = `$${total.toFixed(2)}`;
    if (checkoutDiscount) {
      if (discount > 0) {
        checkoutDiscount.parentElement.style.display = 'flex';
        checkoutDiscount.textContent = `-$${discount.toFixed(2)}`;
      } else {
        checkoutDiscount.parentElement.style.display = 'none';
      }
    }
  }

  showToast(message) {
    let container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `
      <div class="toast-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
      </div>
      <div>
        <div class="toast-title">Lumina Atelier</div>
        <div class="toast-message">${message}</div>
      </div>
    `;

    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 400);
    }, 3500);
  }
}

// Instantiate globally
document.addEventListener('DOMContentLoaded', () => {
  window.cartManager = new CartManager();
});
