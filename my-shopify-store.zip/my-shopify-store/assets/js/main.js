/* ==========================================================================
   LUMINA ATELIER - MAIN APP (main.js)
   Renders catalog, collection filters, header scroll, & checkout logic
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initHeaderScroll();
  initMobileNav();
  renderFeaturedProducts('all');
  initProductFilters();
  renderTestimonials();
  initNewsletter();
  initCheckoutFlow();
  initAnnouncementBar();
});

/* --------------------------------------------------------------------------
   1. STICKY HEADER SCROLL LISTENER
   -------------------------------------------------------------------------- */
function initHeaderScroll() {
  const header = document.querySelector('.site-header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  }, { passive: true });
}

/* --------------------------------------------------------------------------
   2. MOBILE NAVIGATION DRAWER
   -------------------------------------------------------------------------- */
function initMobileNav() {
  const mobileToggle = document.getElementById('mobileNavToggle');
  const drawer = document.getElementById('mobileNavDrawer');
  const backdrop = document.getElementById('mobileNavBackdrop');
  const closeBtn = document.getElementById('mobileNavCloseBtn');
  const mobileLinks = document.querySelectorAll('.mobile-nav-link');

  function openMenu() {
    if (drawer && backdrop) {
      drawer.classList.add('active');
      backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeMenu() {
    if (drawer && backdrop) {
      drawer.classList.remove('active');
      backdrop.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (mobileToggle) mobileToggle.addEventListener('click', openMenu);
  if (closeBtn) closeBtn.addEventListener('click', closeMenu);
  if (backdrop) backdrop.addEventListener('click', closeMenu);

  mobileLinks.forEach(link => {
    link.addEventListener('click', closeMenu);
  });
}

/* --------------------------------------------------------------------------
   3. RENDER FEATURED PRODUCTS
   -------------------------------------------------------------------------- */
function renderFeaturedProducts(categoryFilter = 'all') {
  const container = document.getElementById('featuredProductsGrid');
  if (!container) return;

  const filtered = categoryFilter === 'all' 
    ? PRODUCTS_DATA 
    : PRODUCTS_DATA.filter(p => p.category === categoryFilter);

  container.style.opacity = '0';
  
  setTimeout(() => {
    container.innerHTML = filtered.map(product => {
      const isWishlisted = window.wishlistManager ? window.wishlistManager.isWishlisted(product.id) : false;
      const badgeHtml = product.badge 
        ? `<span class="badge badge-${product.badgeType || 'bestseller'}">${product.badge}</span>` 
        : '';
      
      const comparePriceHtml = product.compareAtPrice 
        ? `<span class="price-compare">$${product.compareAtPrice.toFixed(2)}</span>
           <span class="price-discount">-${Math.round((1 - product.price / product.compareAtPrice) * 100)}%</span>` 
        : '';

      const swatchesHtml = product.colors && product.colors.length > 0 
        ? product.colors.map((c, i) => `
            <span 
              class="swatch-dot ${i === 0 ? 'active' : ''}" 
              style="background-color: ${c.hex};" 
              title="${c.name}">
            </span>
          `).join('')
        : '';

      return `
        <article class="product-card" data-product-id="${product.id}" data-category="${product.category}">
          <div class="product-media">
            <img src="${product.images[0]}" alt="${product.title}" class="product-img" loading="lazy" />
            ${product.images[1] ? `<img src="${product.images[1]}" alt="${product.title} alternative view" class="product-img product-img-secondary" loading="lazy" />` : ''}
            
            <div class="product-badges">
              ${badgeHtml}
            </div>

            <div class="product-actions-top">
              <button 
                type="button" 
                class="btn-wishlist ${isWishlisted ? 'active' : ''}" 
                data-wishlist-id="${product.id}" 
                aria-label="Save to Wishlist" 
                title="Add to Wishlist">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                </svg>
              </button>
            </div>

            <div class="product-quick-actions">
              <button 
                type="button" 
                class="btn-quick-add" 
                onclick="window.cartManager.addItem('${product.id}', 1)">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                  <line x1="3" y1="6" x2="21" y2="6"></line>
                  <path d="M16 10a4 4 0 0 1-8 0"></path>
                </svg>
                Quick Add
              </button>
              <button 
                type="button" 
                class="btn-quick-view" 
                data-quickview-id="${product.id}" 
                aria-label="Quick View ${product.title}" 
                title="Quick View">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                  <circle cx="12" cy="12" r="3"></circle>
                </svg>
              </button>
            </div>
          </div>

          <div class="product-info">
            <span class="product-category">${product.categoryName}</span>
            <h3 class="product-title">
              <a href="#quickview" data-quickview-id="${product.id}">${product.title}</a>
            </h3>

            <div class="product-rating">
              <div class="star-rating">
                <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
              </div>
              <span>${product.rating} (${product.reviewsCount})</span>
            </div>

            <div class="product-pricing">
              <span class="price-current">$${product.price.toFixed(2)}</span>
              ${comparePriceHtml}
            </div>

            <div class="product-swatches">
              ${swatchesHtml}
            </div>
          </div>
        </article>
      `;
    }).join('');

    container.style.opacity = '1';
  }, 180);
}

/* --------------------------------------------------------------------------
   4. PRODUCT FILTERS & CATEGORY TILES
   -------------------------------------------------------------------------- */
function initProductFilters() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.getAttribute('data-filter');
      renderFeaturedProducts(cat);
    });
  });

  // Category cards click handles
  document.querySelectorAll('.category-card').forEach(card => {
    card.addEventListener('click', (e) => {
      e.preventDefault();
      const filterKey = card.getAttribute('data-category-target');
      if (filterKey) {
        const matchingBtn = document.querySelector(`.filter-btn[data-filter="${filterKey}"]`);
        if (matchingBtn) {
          matchingBtn.click();
        }
        const collectionSec = document.getElementById('featuredCollectionSection');
        if (collectionSec) {
          collectionSec.scrollIntoView({ behavior: 'smooth' });
        }
      }
    });
  });
}

/* --------------------------------------------------------------------------
   5. TESTIMONIALS
   -------------------------------------------------------------------------- */
function renderTestimonials() {
  const container = document.getElementById('testimonialsGrid');
  if (!container) return;

  container.innerHTML = TESTIMONIALS_DATA.map(item => `
    <div class="testimonial-card">
      <div>
        <div class="testimonial-stars star-rating">
          ${Array(5).fill('<svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 12 2"></polygon></svg>').join('')}
        </div>
        <p class="testimonial-quote">“${item.quote}”</p>
      </div>
      <div class="testimonial-author">
        <img src="${item.avatar}" alt="${item.author}" class="testimonial-avatar" />
        <div class="author-info">
          <h5>
            ${item.author}
            <svg viewBox="0 0 24 24" title="Verified Patron"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
          </h5>
          <span>${item.location} • Verified Buyer</span>
        </div>
      </div>
    </div>
  `).join('');
}

/* --------------------------------------------------------------------------
   6. NEWSLETTER SUBSCRIPTION
   -------------------------------------------------------------------------- */
function initNewsletter() {
  const form = document.getElementById('newsletterForm');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const emailInput = document.getElementById('newsletterEmail');
    const email = emailInput ? emailInput.value.trim() : '';

    if (!email || !email.includes('@')) {
      alert('Please enter a valid email address.');
      return;
    }

    if (window.cartManager) {
      window.cartManager.showToast(`Welcome to the Atelier! Use code LUMINA15 for 15% off.`);
      window.cartManager.applyCoupon('LUMINA15');
    }

    if (emailInput) emailInput.value = '';
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.textContent = 'Subscribed ✓';
      submitBtn.style.backgroundColor = 'var(--color-success)';
      setTimeout(() => {
        submitBtn.textContent = 'Join The Atelier';
        submitBtn.style.backgroundColor = '';
      }, 4000);
    }
  });
}

/* --------------------------------------------------------------------------
   7. MOCK CHECKOUT FLOW
   -------------------------------------------------------------------------- */
function initCheckoutFlow() {
  const checkoutForm = document.getElementById('mockCheckoutForm');
  const paymentMethods = document.querySelectorAll('.payment-method-card');

  // Select mock payment method
  paymentMethods.forEach(method => {
    method.addEventListener('click', () => {
      paymentMethods.forEach(m => m.classList.remove('selected'));
      method.classList.add('selected');
    });
  });

  if (!checkoutForm) return;

  checkoutForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const nameInput = document.getElementById('checkoutName');
    const emailInput = document.getElementById('checkoutEmail');
    const addressInput = document.getElementById('checkoutAddress');

    if (!nameInput.value || !emailInput.value || !addressInput.value) {
      alert('Please fill out your contact and shipping information.');
      return;
    }

    const placeOrderBtn = document.getElementById('btnPlaceOrder');
    if (placeOrderBtn) {
      placeOrderBtn.disabled = true;
      placeOrderBtn.textContent = 'Securing atelier allocation...';
    }

    setTimeout(() => {
      // Generate simulated order confirmation
      const randomOrderNum = Math.floor(10000 + Math.random() * 90000);
      const orderNumEl = document.getElementById('confirmedOrderNumber');
      if (orderNumEl) orderNumEl.textContent = `#LUMINA-${randomOrderNum}`;

      const formView = document.getElementById('checkoutFormView');
      const successView = document.getElementById('checkoutSuccessView');

      if (formView && successView) {
        formView.style.display = 'none';
        successView.style.display = 'block';
      }

      // Clear cart
      if (window.cartManager) {
        window.cartManager.items = [];
        window.cartManager.saveCart();
        window.cartManager.render();
      }

      if (placeOrderBtn) {
        placeOrderBtn.disabled = false;
        placeOrderBtn.textContent = 'Complete Order';
      }
    }, 1400);
  });
}

/* --------------------------------------------------------------------------
   8. ANNOUNCEMENT BAR PROMO COPY
   -------------------------------------------------------------------------- */
function initAnnouncementBar() {
  const copyBtn = document.getElementById('btnCopyPromo');
  if (!copyBtn) return;

  copyBtn.addEventListener('click', () => {
    const code = "LUMINA15";
    navigator.clipboard.writeText(code).then(() => {
      if (window.cartManager) {
        window.cartManager.showToast(`Code "${code}" copied to clipboard!`);
        window.cartManager.applyCoupon(code);
      }
    }).catch(() => {
      if (window.cartManager) {
        window.cartManager.applyCoupon(code);
      }
    });
  });
}
