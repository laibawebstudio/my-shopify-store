/* ==========================================================================
   LUMINA ATELIER - PRODUCT DATA CATALOG (data.js)
   Maps to Shopify Products, Collections & Variant Schema
   ========================================================================== */

const PRODUCTS_DATA = [
  {
    id: "prod-1",
    handle: "sienna-leather-minimalist-backpack",
    title: "Sienna Minimalist Leather Backpack",
    vendor: "Lumina Leatherworks",
    category: "leather",
    categoryName: "Leather Goods",
    price: 245.00,
    compareAtPrice: 295.00,
    rating: 4.9,
    reviewsCount: 148,
    badge: "Bestseller",
    badgeType: "bestseller",
    description: "Crafted from full-grain Tuscan vegetable-tanned leather, the Sienna Backpack is designed for effortless everyday utility. Features a padded 15\" laptop sleeve, water-resistant microfiber lining, and solid brass Italian hardware.",
    images: [
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80"
    ],
    colors: [
      { name: "Sienna Tan", hex: "#a4633a" },
      { name: "Espresso Black", hex: "#1f1d1c" },
      { name: "Olive Bronze", hex: "#555b46" }
    ],
    sizes: ["One Size"],
    inStock: true,
    stockCount: 6,
    tags: ["bestseller", "leather", "bags", "commute"]
  },
  {
    id: "prod-2",
    handle: "heritage-monochrome-gold-chronograph",
    title: "Heritage Gold Chronograph Watch",
    vendor: "Lumina Horology",
    category: "watches",
    categoryName: "Watches",
    price: 380.00,
    compareAtPrice: 450.00,
    rating: 5.0,
    reviewsCount: 92,
    badge: "Save $70",
    badgeType: "sale",
    description: "A precision Swiss quartz movement encased in 316L brushed surgical-grade stainless steel with 18k champagne gold PVD plating. Features scratch-resistant sapphire crystal and an interchangeable Horween leather strap.",
    images: [
      "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=80"
    ],
    colors: [
      { name: "Champagne Gold", hex: "#d4af37" },
      { name: "Brushed Silver", hex: "#c0c0c0" }
    ],
    sizes: ["38mm", "42mm"],
    inStock: true,
    stockCount: 4,
    tags: ["watches", "sale", "luxury", "horology"]
  },
  {
    id: "prod-3",
    handle: "cashmere-merino-oversized-knit-sweater",
    title: "Cashmere Merino Oversized Knit",
    vendor: "Lumina Knitwear",
    category: "apparel",
    categoryName: "Apparel",
    price: 195.00,
    compareAtPrice: 220.00,
    rating: 4.8,
    reviewsCount: 215,
    badge: "New Arrival",
    badgeType: "new",
    description: "Spun in Northern Italy from an ultra-soft blend of 70% superfine merino wool and 30% Grade-A Mongolian cashmere. Features a relaxed drop-shoulder silhouette with reinforced ribbed cuffs.",
    images: [
      "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=800&q=80"
    ],
    colors: [
      { name: "Oatmeal Melange", hex: "#ded4c3" },
      { name: "Charcoal Heather", hex: "#3b3c3e" },
      { name: "Forest Sage", hex: "#4d5b4e" }
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    inStock: true,
    stockCount: 12,
    tags: ["new", "apparel", "knitwear", "winter"]
  },
  {
    id: "prod-4",
    handle: "artisan-ceramic-pour-over-carafe-set",
    title: "Artisan Ceramic Pour-Over Set",
    vendor: "Lumina Living",
    category: "living",
    categoryName: "Home Living",
    price: 88.00,
    compareAtPrice: null,
    rating: 4.9,
    reviewsCount: 64,
    badge: null,
    badgeType: null,
    description: "Wheel-thrown by master potters using iron-rich stoneware clay. Coated in a matte satin reactive glaze that makes each individual piece completely unique. Heat-retaining thermal density for ritual coffee brewing.",
    images: [
      "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1517256064527-09c73fc73e38?auto=format&fit=crop&w=800&q=80"
    ],
    colors: [
      { name: "Speckled Sand", hex: "#e0d7c7" },
      { name: "Matte Basalt", hex: "#2b2a29" }
    ],
    sizes: ["600ml"],
    inStock: true,
    stockCount: 8,
    tags: ["living", "ceramic", "coffee", "artisan"]
  },
  {
    id: "prod-5",
    handle: "florentine-chelsea-boots-calfskin",
    title: "Florentine Calfskin Chelsea Boots",
    vendor: "Lumina Footwear",
    category: "apparel",
    categoryName: "Apparel",
    price: 320.00,
    compareAtPrice: 380.00,
    rating: 4.9,
    reviewsCount: 110,
    badge: "Save $60",
    badgeType: "sale",
    description: "Handcrafted in Florence using French box calfskin leather. Goodyear welted construction ensures these boots can be resoled for decades. Features custom elastic side gussets and a stacked leather heel.",
    images: [
      "https://images.unsplash.com/photo-1638247025967-b4e38f787b76?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80"
    ],
    colors: [
      { name: "Cognac Amber", hex: "#7a3e21" },
      { name: "Onyx Black", hex: "#1a1918" }
    ],
    sizes: ["40 EU", "41 EU", "42 EU", "43 EU", "44 EU"],
    inStock: true,
    stockCount: 5,
    tags: ["shoes", "apparel", "leather", "bestseller"]
  },
  {
    id: "prod-6",
    handle: "structured-atelier-crossbody-pouch",
    title: "Structured Atelier Crossbody",
    vendor: "Lumina Leatherworks",
    category: "leather",
    categoryName: "Leather Goods",
    price: 185.00,
    compareAtPrice: null,
    rating: 4.7,
    reviewsCount: 88,
    badge: "Popular",
    badgeType: "bestseller",
    description: "Architectural lines meet minimalist form. Features a magnetic accordion flap, interior card slots, and an adjustable strap crafted from smooth semi-aniline leather that patinas gracefully with age.",
    images: [
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80"
    ],
    colors: [
      { name: "Warm Taupe", hex: "#a89b8d" },
      { name: "Noir", hex: "#171717" },
      { name: "Burnt Ochre", hex: "#a05a2c" }
    ],
    sizes: ["One Size"],
    inStock: true,
    stockCount: 15,
    tags: ["leather", "bags", "crossbody"]
  },
  {
    id: "prod-7",
    handle: "botanical-amber-glass-atelier-candle",
    title: "Botanical Amber Scented Candle",
    vendor: "Lumina Living",
    category: "living",
    categoryName: "Home Living",
    price: 48.00,
    compareAtPrice: 60.00,
    rating: 4.8,
    reviewsCount: 175,
    badge: "Staff Pick",
    badgeType: "bestseller",
    description: "Hand-poured in small batches using 100% natural soy wax and lead-free unbleached cotton wicks. Notes of Siberian pine needle, smoked amber resin, aged cedarwood, and delicate cardamon. 65-hour clean burn time.",
    images: [
      "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1602874801007-bd458bb1b8b6?auto=format&fit=crop&w=800&q=80"
    ],
    colors: [
      { name: "Amber Glass", hex: "#c27d38" }
    ],
    sizes: ["280g / 10oz"],
    inStock: true,
    stockCount: 22,
    tags: ["living", "candle", "fragrance", "gift"]
  },
  {
    id: "prod-8",
    handle: "matte-sound-studio-wireless-headphones",
    title: "Acoustic Matte Wireless Studio",
    vendor: "Lumina Acoustics",
    category: "living",
    categoryName: "Home Living",
    price: 290.00,
    compareAtPrice: 340.00,
    rating: 4.9,
    reviewsCount: 310,
    badge: "Save $50",
    badgeType: "sale",
    description: "Engineered with custom 40mm beryllium drivers, active hybrid noise cancellation, and memory foam lambskin earcups for zero-fatigue listening sessions. 40-hour battery life with USB-C fast charging.",
    images: [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=800&q=80"
    ],
    colors: [
      { name: "Matte Black", hex: "#222222" },
      { name: "Sandstone Grey", hex: "#b4b2aa" }
    ],
    sizes: ["Over-Ear"],
    inStock: true,
    stockCount: 7,
    tags: ["audio", "living", "tech", "lifestyle"]
  }
];

const CATEGORIES_DATA = [
  {
    id: "cat-leather",
    name: "Leather Goods",
    filterKey: "leather",
    itemCount: "18 Pieces",
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "cat-apparel",
    name: "Knitwear & Tailoring",
    filterKey: "apparel",
    itemCount: "24 Pieces",
    image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "cat-watches",
    name: "Horology & Objects",
    filterKey: "watches",
    itemCount: "12 Pieces",
    image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "cat-living",
    name: "Curated Living",
    filterKey: "living",
    itemCount: "16 Pieces",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80"
  }
];

const TESTIMONIALS_DATA = [
  {
    quote: "The quality of the leather backpack is staggering. After six months of travel, the patina is developing into an absolute work of art. Lumina represents true quiet luxury.",
    author: "Elena Rostova",
    location: "Zurich, Switzerland",
    verified: true,
    product: "Sienna Leather Backpack",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
  },
  {
    quote: "The Heritage Chronograph arrived in museum-grade packaging. The weight, balance, and finish rival timepieces costing four times as much. Exceptional craftsmanship.",
    author: "Marcus Vance",
    location: "London, UK",
    verified: true,
    product: "Heritage Gold Chronograph",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
  },
  {
    quote: "The cashmere sweater feels like a cloud yet holds its shape effortlessly. Free shipping was remarkably fast to New York. Lumina has become my go-to boutique.",
    author: "Camille Dupont",
    location: "New York, USA",
    verified: true,
    product: "Cashmere Merino Oversized Knit",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80"
  }
];
