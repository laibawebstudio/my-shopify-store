/* ==========================================================================
   LUMINA ATELIER - SEARCH LOGIC (search.js)
   Instant catalog search & predictive results
   ========================================================================== */

class SearchManager {
  constructor() {
    this.modal = document.getElementById('searchModal');
    this.input = document.getElementById('searchModalInput');
    this.resultsGrid = document.getElementById('searchResultsGrid');
    this.closeBtn = document.getElementById('searchCloseBtn');
    this.triggers = document.querySelectorAll('.search-trigger-btn');

    this.initEvents();
  }

  initEvents() {
    this.triggers.forEach(trigger => {
      trigger.addEventListener('click', (e) => {
        e.preventDefault();
        this.open();
      });
    });

    if (this.closeBtn) {
      this.closeBtn.addEventListener('click', () => this.close());
    }

    if (this.modal) {
      this.modal.addEventListener('click', (e) => {
        if (e.target === this.modal) this.close();
      });
    }

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modal && this.modal.classList.contains('active')) {
        this.close();
      }
    });

    if (this.input) {
      this.input.addEventListener('input', (e) => {
        this.handleSearch(e.target.value.trim());
      });
    }

    // Quick tag suggestions
    document.querySelectorAll('.search-tag').forEach(tag => {
      tag.addEventListener('click', () => {
        const query = tag.getAttribute('data-search-query') || tag.textContent.trim();
        if (this.input) {
          this.input.value = query;
          this.handleSearch(query);
        }
      });
    });
  }

  open() {
    if (this.modal) {
      this.modal.classList.add('active');
      document.body.style.overflow = 'hidden';
      setTimeout(() => {
        if (this.input) {
          this.input.focus();
          if (this.input.value) {
            this.handleSearch(this.input.value);
          } else {
            this.renderInitialResults();
          }
        }
      }, 100);
    }
  }

  close() {
    if (this.modal) {
      this.modal.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  renderInitialResults() {
    if (!this.resultsGrid) return;
    const initial = PRODUCTS_DATA.slice(0, 3);
    this.renderCards(initial, "Featured Atelier Pieces");
  }

  handleSearch(query) {
    if (!this.resultsGrid) return;

    if (!query) {
      this.renderInitialResults();
      return;
    }

    const q = query.toLowerCase();
    const results = PRODUCTS_DATA.filter(p => 
      p.title.toLowerCase().includes(q) ||
      p.categoryName.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      (p.tags && p.tags.some(t => t.toLowerCase().includes(q)))
    );

    if (results.length === 0) {
      this.resultsGrid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 2.5rem; color: rgba(255,255,255,0.7);">
          <p style="font-size: 1.1rem; margin-bottom: 0.5rem;">No results found for "${query}"</p>
          <p style="font-size: 0.85rem; color: rgba(255,255,255,0.5);">Try searching for "leather", "knit", "boots", "gold", or "candle"</p>
        </div>
      `;
    } else {
      this.renderCards(results, `${results.length} ${results.length === 1 ? 'Product' : 'Products'} Found`);
    }
  }

  renderCards(products, label) {
    this.resultsGrid.innerHTML = products.map(p => `
      <div class="search-result-card" onclick="window.searchManager.selectProduct('${p.id}')">
        <img src="${p.images[0]}" alt="${p.title}" />
        <div class="search-result-info">
          <h4>${p.title}</h4>
          <span style="font-size:0.75rem; color:rgba(255,255,255,0.6);">${p.categoryName}</span>
          <span>$${p.price.toFixed(2)}</span>
        </div>
      </div>
    `).join('');
  }

  selectProduct(productId) {
    this.close();
    if (window.quickViewManager) {
      setTimeout(() => {
        window.quickViewManager.open(productId);
      }, 250);
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.searchManager = new SearchManager();
});
