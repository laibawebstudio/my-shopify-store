/* ==========================================================================
   LUMINA ATELIER - PRODUCT QUICK VIEW MODAL (quickview.js)
   Maps to Shopify Section modal / snippets/quick-view.liquid
   ========================================================================== */

class QuickViewManager {
  constructor() {
    this.modal = document.getElementById('quickViewModal');
    this.backdrop = document.getElementById('quickViewBackdrop');
    this.currentProduct = null;
    this.selectedColor = null;
    this.selectedSize = null;
    this.quantity = 1;

    this.initEvents();
  }

  initEvents() {
    // Backdrop close
    if (this.backdrop) {
      this.backdrop.addEventListener('click', () => this.close());
    }

    // Modal Close Button
    const closeBtn = document.getElementById('quickViewCloseBtn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.close());
    }

    // Keyboard ESC to close
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modal && this.modal.classList.contains('active')) {
        this.close();
      }
    });

    // Delegate quick view triggers
    document.addEventListener('click', (e) => {
      const trigger = e.target.closest('[data-quickview-id]');
      if (trigger) {
        e.preventDefault();
        const prodId = trigger.getAttribute('data-quickview-id');
        this.open(prodId);
      }
    });
  }

  open(productId) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    this.currentProduct = product;
    this.selectedColor = product.colors && product.colors.length > 0 ? product.colors[0].name : "Standard";
    this.selectedSize = product.sizes && product.sizes.length > 0 ? product.sizes[0] : "One Size";
    this.quantity = 1;

    this.renderContent();

    if (this.modal && this.backdrop) {
      this.modal.classList.add('active');
      this.backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  close() {
    if (this.modal && this.backdrop) {
      this.modal.classList.remove('active');
      this.backdrop.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  renderContent() {
    const p = this.currentProduct;
    if (!p) return;

    // Gallery
    const mainImg = document.getElementById('qvMainImage');
    const thumbsContainer = document.getElementById('qvThumbnails');

    if (mainImg) {
      mainImg.src = p.images[0];
      mainImg.alt = p.title;
    }

    if (thumbsContainer) {
      thumbsContainer.innerHTML = p.images.map((imgUrl, i) => `
        <img 
          src="${imgUrl}" 
          alt="${p.title} view ${i + 1}" 
          class="quickview-thumb ${i === 0 ? 'active' : ''}" 
          onclick="window.quickViewManager.switchImage('${imgUrl}', this)"
        />
      `).join('');
    }

    // Title & details
    const vendorEl = document.getElementById('qvVendor');
    const titleEl = document.getElementById('qvTitle');
    const priceEl = document.getElementById('qvPrice');
    const comparePriceEl = document.getElementById('qvComparePrice');
    const descEl = document.getElementById('qvDescription');
    const stockEl = document.getElementById('qvStockCount');

    if (vendorEl) vendorEl.textContent = p.vendor;
    if (titleEl) titleEl.textContent = p.title;
    if (priceEl) priceEl.textContent = `$${p.price.toFixed(2)}`;

    if (comparePriceEl) {
      if (p.compareAtPrice) {
        comparePriceEl.style.display = 'inline';
        comparePriceEl.textContent = `$${p.compareAtPrice.toFixed(2)}`;
      } else {
        comparePriceEl.style.display = 'none';
      }
    }

    if (descEl) descEl.textContent = p.description;
    if (stockEl) stockEl.textContent = p.stockCount;

    // Color Swatches
    const colorLabel = document.getElementById('qvColorLabel');
    const swatchesContainer = document.getElementById('qvSwatches');
    if (colorLabel) colorLabel.textContent = this.selectedColor;

    if (swatchesContainer) {
      if (p.colors && p.colors.length > 0) {
        swatchesContainer.innerHTML = p.colors.map((c, i) => `
          <button 
            type="button" 
            class="swatch-dot ${i === 0 ? 'active' : ''}" 
            style="background-color: ${c.hex};" 
            title="${c.name}"
            onclick="window.quickViewManager.selectColor('${c.name}', this)">
          </button>
        `).join('');
      } else {
        swatchesContainer.innerHTML = '';
      }
    }

    // Size Chips
    const sizeLabel = document.getElementById('qvSizeLabel');
    const sizeChipsContainer = document.getElementById('qvSizeChips');
    if (sizeLabel) sizeLabel.textContent = this.selectedSize;

    if (sizeChipsContainer) {
      if (p.sizes && p.sizes.length > 0) {
        sizeChipsContainer.innerHTML = p.sizes.map((s, i) => `
          <button 
            type="button" 
            class="size-chip ${i === 0 ? 'active' : ''}" 
            onclick="window.quickViewManager.selectSize('${s}', this)">
            ${s}
          </button>
        `).join('');
      } else {
        sizeChipsContainer.innerHTML = '';
      }
    }

    // Quantity Input
    const qtyInput = document.getElementById('qvQuantityValue');
    if (qtyInput) qtyInput.textContent = this.quantity;

    // Add to cart button binding
    const addToCartBtn = document.getElementById('qvAddToCartBtn');
    if (addToCartBtn) {
      addToCartBtn.onclick = () => {
        if (window.cartManager) {
          window.cartManager.addItem(p.id, this.quantity, {
            color: this.selectedColor,
            size: this.selectedSize
          });
          this.close();
        }
      };
    }
  }

  switchImage(imgUrl, thumbEl) {
    const mainImg = document.getElementById('qvMainImage');
    if (mainImg) {
      mainImg.style.opacity = '0.5';
      setTimeout(() => {
        mainImg.src = imgUrl;
        mainImg.style.opacity = '1';
      }, 150);
    }
    const thumbs = document.querySelectorAll('.quickview-thumb');
    thumbs.forEach(t => t.classList.remove('active'));
    if (thumbEl) thumbEl.classList.add('active');
  }

  selectColor(colorName, dotEl) {
    this.selectedColor = colorName;
    const colorLabel = document.getElementById('qvColorLabel');
    if (colorLabel) colorLabel.textContent = colorName;

    const dots = document.querySelectorAll('#qvSwatches .swatch-dot');
    dots.forEach(d => d.classList.remove('active'));
    if (dotEl) dotEl.classList.add('active');
  }

  selectSize(sizeName, chipEl) {
    this.selectedSize = sizeName;
    const sizeLabel = document.getElementById('qvSizeLabel');
    if (sizeLabel) sizeLabel.textContent = sizeName;

    const chips = document.querySelectorAll('#qvSizeChips .size-chip');
    chips.forEach(c => c.classList.remove('active'));
    if (chipEl) chipEl.classList.add('active');
  }

  updateQuantity(delta) {
    this.quantity = Math.max(1, this.quantity + delta);
    const qtyInput = document.getElementById('qvQuantityValue');
    if (qtyInput) qtyInput.textContent = this.quantity;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.quickViewManager = new QuickViewManager();
});
