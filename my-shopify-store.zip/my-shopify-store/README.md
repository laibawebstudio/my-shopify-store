# LUMINA ATELIER — Modern Luxury E-Commerce Storefront

An ultra-clean, high-conversion modern e-commerce storefront crafted with semantic HTML5, modern CSS3, and modular vanilla JavaScript. Designed with luxury editorial aesthetics and pre-architected for seamless conversion into a **Shopify Online Store 2.0** theme.

---

## ✨ Features & Components

- **Announcement Bar**: Sticky top ticker featuring promo code auto-copy (`LUMINA15` for 15% off) and value badges.
- **Glassmorphism Header**: Sticky frosted-glass navigation with animated badge counters for cart and wishlist, search overlay trigger, and mobile drawer toggle.
- **High-Impact Hero Banner**: Editorial luxury hero with responsive typography, dual CTA buttons, and trust metrics.
- **Value Proposition Bar**: 4 key buyer assurance pillars (Free Shipping over $150, 30-Day Home Trial, Sustainable Craftsmanship, Encrypted Checkout).
- **Curated Category Grid**: 4 department tiles with hover zoom micro-interactions.
- **Interactive Product Catalog**:
  - Filterable by department (All, Leather Goods, Apparel & Footwear, Watches, Curated Living).
  - Secondary image crossfade on card hover.
  - Badges ("Bestseller", "Save $70", "New Arrival").
  - Clickable color swatches.
  - Wishlist heart toggle with localStorage persistence.
  - 1-Click "Quick Add" to cart with toast feedback.
  - "Quick View" modal trigger.
- **Product Quick View Modal**:
  - Image gallery with interactive thumbnail switching.
  - Variant selectors for Color and Size.
  - Real-time stock urgency indicator.
  - Quantity stepper with direct cart sync.
- **Side Slide-Over Cart Drawer**:
  - Animated item count badge.
  - Dynamic Free Shipping Progress Meter ($150 target with live distance calculation).
  - Item list with quantity steppers and remove triggers.
  - Promotional discount coupon input (`LUMINA15`, `SAVE10`, `FREESHIP`).
  - Subtotal, discounts, shipping, and total calculation.
  - "Proceed to Checkout" flow.
- **Mock Checkout Modal (Safe Demo)**:
  - Step-by-step Shopify-style checkout preview (Contact, Shipping, Mock Payment Method).
  - Safe test environment — **no real payment credentials required or stored**.
  - Simulated order confirmation modal with unique order reference (e.g. `#LUMINA-88421`).
- **Live Predictive Search**: Fullscreen overlay with instant catalog query matching and category tags.
- **Artisan Storytelling Section**: Editorial split-layout highlighting small-batch manufacturing.
- **Customer Testimonials**: Verified patron quotes with 5-star ratings.
- **Instagram / Community UGC Feed**: Grid of lifestyle photos with hover tags.
- **VIP Newsletter Subscription**: Instant coupon toast notification on signup.
- **Footer**: Comprehensive navigation, concierge details, copyright, and payment provider badges.
- **Fully Responsive**: Optimized for ultra-wide monitors, laptops, tablets, and smartphones.

---

## 📁 Project Architecture

```
my-shopify-store/
├── index.html                   # Main previewable storefront
├── README.md                    # Project documentation
├── SHOPIFY_CONVERSION_GUIDE.md  # Detailed Shopify OS 2.0 porting guide
├── sections/                    # Shopify OS 2.0 Liquid section references
│   ├── hero-banner.liquid       # Liquid template + JSON schema
│   └── featured-collection.liquid # Liquid loop + schema
└── assets/
    ├── css/
    │   ├── variables.css        # Design tokens & color variables
    │   ├── main.css             # Base reset, typography, buttons, utilities
    │   ├── components.css       # Header, Hero, Cards, Testimonials, Footer
    │   ├── cart.css             # Cart drawer, Modals, Checkout, Toasts
    │   └── responsive.css       # Media queries & mobile navigation drawer
    └── js/
        ├── data.js              # Product catalog data (schema ready)
        ├── cart.js              # Cart state, free shipping meter, discounts
        ├── quickview.js         # Quick View modal & variant switcher
        ├── wishlist.js          # Wishlist persistence & badge counters
        ├── search.js            # Instant predictive search overlay
        └── main.js              # App orchestration & interactions
```

---

## 🚀 How to Preview

You can preview the website immediately in multiple ways:

### Option 1: Direct File Open
Double-click `index.html` in your file explorer, or right-click `index.html` and choose **Open with > Chrome / Edge / Firefox / Safari**.

### Option 2: Local HTTP Server (PowerShell / Command Prompt)
Run any local server in the project folder:

```powershell
# Using Python:
python -m http.server 8000

# Or using Node.js npx:
npx serve .
```
Then visit `http://localhost:8000` in your web browser.

---

## 🛍️ Shopify Online Store 2.0 Readiness

Every HTML section in `index.html` is commented with its corresponding Shopify 2.0 section name (e.g. `<!-- SECTION: hero-banner.liquid -->`, `<!-- SNIPPET: cart-drawer.liquid -->`). 

See [`SHOPIFY_CONVERSION_GUIDE.md`](./SHOPIFY_CONVERSION_GUIDE.md) for full instructions on mapping HTML sections to Liquid schemas, integrating Shopify's AJAX Cart API (`/cart/add.js`), and creating `templates/index.json`.
